using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonExit : MonoBehaviour{

    public void quit(){
        Application.Quit(); // fazendo sair do jogo
    }
    
}